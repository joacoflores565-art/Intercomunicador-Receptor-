import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.net.*;
import java.io.*;

/**
 * INTERCOMUNICADOR - Programa del que llama (interfaz + emisor en un solo archivo)
 * -----------------------------------------------------------------------------
 * Es la fusión de lo que antes eran dos archivos separados (la interfaz de
 * prueba local "Intercomunicador.java" y el "Emisor.java" que llamaba por
 * red): ahora es UN SOLO programa, con la interfaz de siempre (botón de
 * llamada + nivel de micrófono) que además busca la sala en la red y
 * transmite el audio en vivo.
 *
 * NOVEDAD - Reconexión automática:
 * Si la llamada se corta a mitad de camino (la sala se reinició, se cayó el
 * Wi-Fi un instante, etc.), el programa NO corta la llamada del lado del
 * usuario: reintenta solo, cada pocos segundos, hasta reconectar o hasta que
 * el usuario presione "CORTAR LLAMADA" a propósito.
 */
public class Intercomunicador extends JFrame {

    static final int PUERTO_DESCUBRIMIENTO = 9876;
    static final int PUERTO_AUDIO = 9877;
    static final String MENSAJE_DESCUBRIMIENTO = "INTERCOM_DISCOVER";
    static final String MENSAJE_RESPUESTA = "INTERCOM_HERE";
    static final int TIMEOUT_BUSQUEDA_MS = 3000;
    static final int ESPERA_ENTRE_REINTENTOS_MS = 3000;

    static final AudioFormat FORMATO = new AudioFormat(44100f, 16, 1, true, false);

    private volatile TargetDataLine microfono;
    private volatile Socket conexionAudio;

    // deseaLlamar: true mientras el usuario quiere estar en llamada (se
    // mantiene en true durante los reintentos automáticos de reconexión).
    private volatile boolean deseaLlamar = false;

    private JButton btnLlamar;
    private JProgressBar nivelMicrofono;
    private JLabel estado;

    public Intercomunicador() {
        super("Intercomunicador");
        construirInterfaz();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 240);
        setLocationRelativeTo(null);
    }

    private void construirInterfaz() {
        setLayout(new BorderLayout(10, 10));

        estado = new JLabel("Listo para llamar", SwingConstants.CENTER);
        estado.setFont(estado.getFont().deriveFont(Font.BOLD, 14f));
        add(estado, BorderLayout.NORTH);

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        JLabel lblNivel = new JLabel("Nivel de micrófono");
        lblNivel.setAlignmentX(Component.CENTER_ALIGNMENT);
        nivelMicrofono = new JProgressBar(0, 100);
        nivelMicrofono.setStringPainted(true);
        nivelMicrofono.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
        centro.add(lblNivel);
        centro.add(Box.createVerticalStrut(5));
        centro.add(nivelMicrofono);
        add(centro, BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        btnLlamar = new JButton("📞 LLAMAR");
        btnLlamar.addActionListener(this::alPresionarLlamar);
        botones.add(btnLlamar);
        add(botones, BorderLayout.SOUTH);
    }

    private void alPresionarLlamar(ActionEvent e) {
        if (!deseaLlamar) {
            deseaLlamar = true;
            btnLlamar.setText("⏹ CORTAR LLAMADA");
            new Thread(this::cicloDeLlamada, "hilo-llamada").start();
        } else {
            deseaLlamar = false;
            cerrarRecursosActuales();
        }
    }

    /**
     * Bucle principal de la llamada. Mientras el usuario quiera estar
     * llamando (deseaLlamar == true), intenta buscar la sala, conectarse y
     * transmitir. Si algo se corta y el usuario todavía quiere llamar,
     * espera un momento y reintenta automáticamente desde cero (por si la
     * sala cambió de IP, por ejemplo).
     */
    private void cicloDeLlamada() {
        while (deseaLlamar) {
            try {
                actualizarEstado("Buscando sala en la red...");
                InetAddress ipSala = buscarSala();

                if (ipSala == null) {
                    actualizarEstado("No se encontró sala. Reintentando en 3s...");
                    esperar(ESPERA_ENTRE_REINTENTOS_MS);
                    continue;
                }

                conexionAudio = new Socket();
                conexionAudio.connect(new InetSocketAddress(ipSala, PUERTO_AUDIO), TIMEOUT_BUSQUEDA_MS);
                abrirMicrofono();

                actualizarEstado("Llamando a " + ipSala.getHostAddress() + "...");
                transmitirAudio(); // bloquea hasta que se corte la conexión o el usuario cancele

            } catch (IOException | LineUnavailableException ex) {
                if (deseaLlamar) {
                    actualizarEstado("Se perdió la conexión. Reconectando...");
                }
            } finally {
                cerrarRecursosActuales();
            }

            if (deseaLlamar) {
                esperar(ESPERA_ENTRE_REINTENTOS_MS);
            }
        }

        actualizarEstado("Listo para llamar");
        SwingUtilities.invokeLater(() -> {
            btnLlamar.setText("📞 LLAMAR");
            nivelMicrofono.setValue(0);
        });
    }

    private InetAddress buscarSala() {
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setBroadcast(true);
            socket.setSoTimeout(TIMEOUT_BUSQUEDA_MS);

            byte[] mensaje = MENSAJE_DESCUBRIMIENTO.getBytes();
            InetAddress direccionBroadcast = InetAddress.getByName("255.255.255.255");
            socket.send(new DatagramPacket(mensaje, mensaje.length, direccionBroadcast, PUERTO_DESCUBRIMIENTO));

            byte[] buffer = new byte[256];
            DatagramPacket respuesta = new DatagramPacket(buffer, buffer.length);
            socket.receive(respuesta);

            String contenido = new String(respuesta.getData(), 0, respuesta.getLength());
            return MENSAJE_RESPUESTA.equals(contenido) ? respuesta.getAddress() : null;

        } catch (IOException ex) {
            return null; // timeout u otro error de red: se trata igual que "no se encontró"
        }
    }

    private void abrirMicrofono() throws LineUnavailableException {
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMATO);
        microfono = (TargetDataLine) AudioSystem.getLine(info);
        microfono.open(FORMATO);
        microfono.start();
    }

    private void transmitirAudio() throws IOException {
        OutputStream salida = conexionAudio.getOutputStream();
        byte[] bloque = new byte[2048];

        while (deseaLlamar) {
            int leidos = microfono.read(bloque, 0, bloque.length);
            if (leidos > 0) {
                salida.write(bloque, 0, leidos);
                salida.flush();
                int nivel = calcularNivel(bloque, leidos);
                SwingUtilities.invokeLater(() -> nivelMicrofono.setValue(nivel));
            }
        }
    }

    private int calcularNivel(byte[] datos, int cantidad) {
        long suma = 0;
        int muestras = cantidad / 2;
        for (int i = 0; i < cantidad - 1; i += 2) {
            short muestra = (short) ((datos[i + 1] << 8) | (datos[i] & 0xFF));
            suma += (long) muestra * muestra;
        }
        double rms = muestras > 0 ? Math.sqrt((double) suma / muestras) : 0;
        return Math.min(100, Math.max(0, (int) (rms / 327.68)));
    }

    private void cerrarRecursosActuales() {
        TargetDataLine micActual = microfono;
        if (micActual != null) {
            micActual.stop();
            micActual.close();
        }
        microfono = null;

        Socket socketActual = conexionAudio;
        if (socketActual != null) {
            try {
                socketActual.close();
            } catch (IOException ignored) {}
        }
        conexionAudio = null;
    }

    private void esperar(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

    private void actualizarEstado(String texto) {
        SwingUtilities.invokeLater(() -> estado.setText(texto));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Intercomunicador().setVisible(true));
    }
}
