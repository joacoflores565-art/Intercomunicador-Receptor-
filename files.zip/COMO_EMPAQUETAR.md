# Cómo convertir los .jar en instaladores .exe para Windows

Te dejo los dos programas ya compilados y probados:

- **Intercomunicador.jar** → el que llama (interfaz + búsqueda de sala +
  reconexión automática). Se instala en la/s PC que van a llamar.
- **Receptor.jar** → la sala (ícono de bandeja + auto-recuperación). Se
  instala en la PC que siempre está escuchando.

Estos `.jar` ya son "un solo archivo": si la PC tiene Java instalado, con
doble clic funcionan. Pero para que sean un instalador `.exe` normal de
Windows (sin depender de que el usuario tenga Java, y con ícono de
escritorio automático), hay que darles un paso más con `jpackage`.

## ⚠️ Importante: este paso se hace en una PC con Windows

`jpackage` genera el instalador para el sistema operativo **en el que se
ejecuta el comando**. Como yo trabajo en un entorno Linux, no puedo generar
el `.exe` de Windows desde acá — pero sí dejé el código ya compilado y
probado, así que en tu PC Windows este paso es mecánico y rápido.

### Requisitos en la PC Windows donde vas a empaquetar

1. Tener instalado el **JDK 17 o superior** (por ejemplo, Eclipse Temurin,
   gratuito: https://adoptium.net).
2. Instalar el **WiX Toolset v3** (lo pide `jpackage` para armar el
   instalador `.exe` en Windows): https://wixtoolset.org/releases

(Estos dos programas solo hacen falta en la PC donde generás el instalador,
**no** en las PCs finales donde después se instala el intercomunicador.)

## Pasos

1. Copiá `Intercomunicador.jar` y `Receptor.jar` a una carpeta en esa PC
   Windows.

2. Abrí una terminal (CMD o PowerShell) en esa carpeta y corré, para el
   emisor:

   ```
   jpackage --input . --name Intercomunicador --main-jar Intercomunicador.jar --main-class Intercomunicador --type exe --win-shortcut --win-menu
   ```

3. Y para el receptor:

   ```
   jpackage --input . --name Receptor --main-jar Receptor.jar --main-class Receptor --type exe --win-shortcut --win-menu
   ```

4. Cada comando te va a dejar un instalador, por ejemplo
   `Intercomunicador-1.0.exe` y `Receptor-1.0.exe`. Ese es el archivo final
   para repartir.

### Qué hace cada opción

| Opción | Para qué sirve |
|---|---|
| `--type exe` | Genera un instalador `.exe` de Windows (en vez de una carpeta suelta). |
| `--win-shortcut` | Crea automáticamente el **ícono de acceso directo en el escritorio** al instalar — es justo lo que pediste para el Receptor, y también queda bien para el Intercomunicador. |
| `--win-menu` | Además lo agrega al menú Inicio de Windows. |

El instalador que resulta **incluye una copia de Java adentro**, así que
las PCs donde lo instales no necesitan tener Java preinstalado — se ejecuta
como cualquier programa común de Windows.

## Instalación final en cada PC

- PC(s) que llaman → instalar `Intercomunicador-1.0.exe`.
- PC de la sala → instalar `Receptor-1.0.exe`. Para que arranque solo cada
  vez que se prende la PC (por si hay un corte de luz o un reinicio), después
  de instalarlo: `Win + R` → `shell:startup` → ahí arrastrás un acceso
  directo al Receptor instalado.
- En la PC del Receptor, la primera vez que Windows Defender Firewall
  pregunte si permitís la conexión, decir que sí (o agregarlo a mano en
  Firewall → permitir una app, puertos 9876 UDP y 9877 TCP).

## Si preferís no instalar WiX / hacerlo más simple

Si no querés lidiar con WiX Toolset, hay una alternativa más simple pero
menos "profesional": repartir directamente el `.jar` junto con un archivo
`.bat` con esta única línea:

```
javafw.exe -jar Intercomunicador.jar
```

(o simplemente `java -jar Intercomunicador.jar`), y pedirle a cada PC que
tenga el JRE de Java instalado una sola vez (gratis, desde
https://adoptium.net). No queda tan "un solo .exe", pero funciona igual de
bien y es mucho menos trabajo.
