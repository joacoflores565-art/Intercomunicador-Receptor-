import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.net.*;
import java.io.*;

/**
 * RECEPTOR (SALA DE ESPERA) - con ícono de bandeja y auto-recuperación
 * -----------------------------------------------------------------------
 * Corre en segundo plano escuchando descubrimiento (UDP 9876) y audio
 * (TCP 9877), y reproduce lo que llega sin pedir confirmación.
 *
 * Ícono en la bandeja del sistema (al lado del reloj de Windows), como un
 * semáforo de estado, dibujado como ondas de Wi-Fi:
 *   🟢 Verde   -> los dos servicios activos y escuchando bien.
 *   🟠 Naranja -> uno de los dos falló (parcial).
 *   ⚫ Tachado -> ninguno de los dos está funcionando.
 *
 * "Reconexión automática" de este lado: como el Receptor no llama a nadie
 * (solo escucha), lo que puede fallar es que uno de sus dos servicios se
 * caiga (por ejemplo si el Wi-Fi se corta un instante y el socket revienta).
 * En vez de quedar caído para siempre, cada servicio se reinicia solo cada
 * pocos segundos hasta volver a levantar - por eso el ícono puede pasar de
 * tachado a verde de nuevo sin que nadie reinicie el programa a mano.
 *
 * La ventana se puede cerrar con la "X" y el programa sigue vivo en la
 * bandeja. Para salir de verdad: clic derecho en el ícono -> "Salir".
 */
public class Receptor extends JFrame {

    static final int PUERTO_DESCUBRIMIENTO = 9876;
    static final int PUERTO_AUDIO = 9877;
    static final String MENSAJE_DESCUBRIMIENTO = "INTERCOM_DISCOVER";
    static final String MENSAJE_RESPUESTA = "INTERCOM_HERE";
    static final AudioFormat FORMATO = new AudioFormat(44100f, 16, 1, true, false);
    static final int ESPERA_REINICIO_MS = 4000;

    private JLabel estado;

    private volatile boolean descubrimientoActivo = false;
    private volatile boolean audioActivo = false;
    private volatile String errorDescubrimiento = null;
    private volatile String errorAudio = null;

    private TrayIcon trayIcon;
    private Image iconoConectado;
    private Image iconoParcial;
    private Image iconoCaido;

    public Receptor() {
        super("Receptor - Sala de Espera");
        construirInterfaz();
        prepararIconosTray();
        configurarCierreAVentanaOculta();
        setSize(380, 180);
        setLocationRelativeTo(null);
    }

    private void construirInterfaz() {
        setLayout(new BorderLayout());
        estado = new JLabel("Iniciando...", SwingConstants.CENTER);
        estado.setFont(estado.getFont().deriveFont(Font.BOLD, 16f));
        add(estado, BorderLayout.CENTER);

        try {
            String ip = InetAddress.getLocalHost().getHostAddress();
            JLabel info = new JLabel("IP de esta sala: " + ip, SwingConstants.CENTER);
            add(info, BorderLayout.SOUTH);
        } catch (UnknownHostException ignored) {}
    }

    private void configurarCierreAVentanaOculta() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (SystemTray.isSupported()) {
                    setVisible(false);
                } else {
                    System.exit(0);
                }
            }
        });
    }

    // ================== ÍCONO DE BANDEJA ==================

    private void prepararIconosTray() {
        if (!SystemTray.isSupported()) return;

        iconoConectado = crearIconoWifi(new Color(40, 170, 80), false);
        iconoParcial = crearIconoWifi(new Color(230, 150, 30), false);
        iconoCaido = crearIconoWifi(Color.GRAY, true);

        PopupMenu menu = new PopupMenu();
        MenuItem itemMostrar = new MenuItem("Mostrar ventana");
        itemMostrar.addActionListener(e -> mostrarVentana());
        MenuItem itemSalir = new MenuItem("Salir");
        itemSalir.addActionListener(e -> System.exit(0));
        menu.add(itemMostrar);
        menu.addSeparator();
        menu.add(itemSalir);

        trayIcon = new TrayIcon(iconoCaido, "Receptor - iniciando...", menu);
        trayIcon.setImageAutoSize(true);
        trayIcon.addActionListener(e -> mostrarVentana());

        try {
            SystemTray.getSystemTray().add(trayIcon);
        } catch (AWTException ex) {
            trayIcon = null;
        }
    }

    private void mostrarVentana() {
        setVisible(true);
        setState(JFrame.NORMAL);
        toFront();
    }

    private Image crearIconoWifi(Color color, boolean tachado) {
        int size = 32;
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(color);

        int cx = size / 2;
        int cy = size - 6;

        g.fillOval(cx - 2, cy - 2, 4, 4);
        g.drawArc(cx - 6, cy - 10, 12, 12, 35, 110);
        g.drawArc(cx - 11, cy - 15, 22, 22, 35, 110);
        g.drawArc(cx - 16, cy - 20, 32, 32, 35, 110);

        if (tachado) {
            g.setColor(new Color(220, 50, 50));
            g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.drawLine(4, 4, size - 4, size - 4);
        }

        g.dispose();
        return img;
    }

    private void actualizarIconoTray() {
        if (trayIcon == null) return;

        Image icono;
        String tooltip;

        if (descubrimientoActivo && audioActivo) {
            icono = iconoConectado;
            tooltip = "Receptor activo - escuchando en la red";
        } else if (!descubrimientoActivo && !audioActivo) {
            icono = iconoCaido;
            tooltip = "Receptor caído: reintentando...";
        } else {
            icono = iconoParcial;
            String detalle = !descubrimientoActivo
                    ? "descubrimiento con problemas (" + errorDescubrimiento + ")"
                    : "audio con problemas (" + errorAudio + ")";
            tooltip = "Receptor parcial: " + detalle;
        }

        SwingUtilities.invokeLater(() -> {
            trayIcon.setImage(icono);
            trayIcon.setToolTip(tooltip);
        });
    }

    private void actualizarEstado(String texto) {
        SwingUtilities.invokeLater(() -> estado.setText(texto));
    }

    private void esperar(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

    // ================== SERVICIO DE DESCUBRIMIENTO (UDP), con auto-reinicio ==================

    private void iniciarServidorDescubrimiento() {
        Thread hilo = new Thread(() -> {
            while (true) {
                try (DatagramSocket socket = new DatagramSocket(PUERTO_DESCUBRIMIENTO)) {
                    descubrimientoActivo = true;
                    errorDescubrimiento = null;
                    actualizarIconoTray();
                    actualizarEstado("Esperando llamadas...");

                    byte[] buffer = new byte[256];
                    while (true) {
                        DatagramPacket entrante = new DatagramPacket(buffer, buffer.length);
                        socket.receive(entrante);

                        String mensaje = new String(entrante.getData(), 0, entrante.getLength());
                        if (MENSAJE_DESCUBRIMIENTO.equals(mensaje)) {
                            byte[] respuesta = MENSAJE_RESPUESTA.getBytes();
                            socket.send(new DatagramPacket(
                                    respuesta, respuesta.length,
                                    entrante.getAddress(), entrante.getPort()));
                        }
                    }
                } catch (IOException ex) {
                    descubrimientoActivo = false;
                    errorDescubrimiento = ex.getMessage();
                    actualizarIconoTray();
                    actualizarEstado("Descubrimiento caído. Reintentando...");
                }
                // Si llegó acá es porque el servicio se cayó: espera un poco y
                // vuelve al principio del while(true) para reintentar solo.
                esperar(ESPERA_REINICIO_MS);
            }
        }, "hilo-descubrimiento");
        hilo.setDaemon(true);
        hilo.start();
    }

    // ================== SERVICIO DE AUDIO (TCP), con auto-reinicio ==================

    private void iniciarServidorAudio() {
        Thread hilo = new Thread(() -> {
            while (true) {
                try (ServerSocket servidor = new ServerSocket(PUERTO_AUDIO)) {
                    audioActivo = true;
                    errorAudio = null;
                    actualizarIconoTray();

                    while (true) {
                        Socket cliente = servidor.accept();
                        new Thread(() -> reproducirLlamada(cliente), "hilo-reproduccion").start();
                    }
                } catch (IOException ex) {
                    audioActivo = false;
                    errorAudio = ex.getMessage();
                    actualizarIconoTray();
                    actualizarEstado("Servidor de audio caído. Reintentando...");
                }
                esperar(ESPERA_REINICIO_MS);
            }
        }, "hilo-servidor-audio");
        hilo.setDaemon(true);
        hilo.start();
    }

    private void reproducirLlamada(Socket cliente) {
        actualizarEstado("🔊 Llamada entrante - reproduciendo...");
        if (trayIcon != null) trayIcon.setToolTip("🔊 Llamada en curso");

        try (Socket s = cliente;
             SourceDataLine parlante = AudioSystem.getSourceDataLine(FORMATO)) {

            parlante.open(FORMATO);
            parlante.start();

            InputStream entrada = s.getInputStream();
            byte[] bloque = new byte[2048];
            int leidos;
            while ((leidos = entrada.read(bloque)) != -1) {
                parlante.write(bloque, 0, leidos);
            }
            parlante.drain();

        } catch (IOException | LineUnavailableException ex) {
            actualizarEstado("Error al reproducir: " + ex.getMessage());
        } finally {
            actualizarEstado("Esperando llamadas...");
            actualizarIconoTray();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Receptor receptor = new Receptor();
            receptor.setVisible(true);
            receptor.iniciarServidorDescubrimiento();
            receptor.iniciarServidorAudio();
        });
    }
}
